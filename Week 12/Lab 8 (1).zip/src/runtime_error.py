"""
CSCI-603 Parser Lab
Author: RIT CS

A custom exception class for representing a runtime error.
"""

class RuntimeError(Exception):
    pass